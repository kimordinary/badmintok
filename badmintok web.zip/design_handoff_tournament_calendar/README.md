# Handoff: 배드민턴 대회 찾기 — 캘린더 + 리스트 (시안 A "정석 리파인")

## Overview
전국 배드민턴 대회를 **찾고·탐색**하는 화면이다. 사용자의 1순위 과업은 "어떤 대회가
있는지 둘러보고 비교하기"다. 핵심 영역은 세 덩어리로 구성된다:

1. **필터** — 구분(전체/전국/지역), 승급 여부(전체/승급/비승급), 지역
2. **월간 캘린더** — 대회를 날짜 위에 막대(range bar)로 표시. 2일 대회는 기간을 가로지름
3. **대회 리스트** — 선택한 날짜(또는 월 전체)의 대회 카드 목록

데스크톱은 캘린더(좌) + 리스트(우) 2단 분할이고, 캘린더↔리스트 **세그먼트 토글**로
전환한다. 모바일은 상단 캘린더(점 표시) + 아래 날짜별 타임라인 리스트, 필터는 바텀시트.

> ⚠️ **목업 헤더는 구현 대상이 아니다.** 프로토타입의 상단 네비게이션(로고, 메뉴,
> 로그인/회원가입)은 화면 맥락을 보여주기 위한 더미일 뿐 기능이 없다. 기존 사이트의
> 헤더를 그대로 쓰고, **캘린더 + 필터 + 리스트 영역만** 구현하면 된다.

## About the Design Files
이 번들의 `source/` 안 파일들은 **HTML/React로 만든 디자인 레퍼런스**다 — 의도한 모양과
동작을 보여주는 프로토타입이지, 그대로 복사해 배포할 프로덕션 코드가 아니다. 작업은 이
디자인을 **대상 코드베이스의 기존 환경(React/Vue/기타)과 패턴·라이브러리에 맞춰 재현**하는
것이다. 환경이 아직 없다면 프로젝트에 가장 적합한 프레임워크를 골라 구현한다.

원본 프로토타입은 미리보기용으로 React 18 + Babel을 CDN에서 불러오고, 디자인 캔버스
래퍼(`DesignCanvas`, `DCSection`, `DCArtboard`) 안에서 여러 시안을 나란히 보여준다.
**캔버스 래퍼와 다른 시안(B/C)은 무시**하고 `variantA.jsx`의 `Desktop`/`Mobile`만 보면 된다.

## Fidelity
**High-fidelity (hifi).** 최종 색상·타이포·간격·인터랙션이 확정된 픽셀 단위 목업이다.
대상 코드베이스의 기존 컴포넌트/라이브러리를 써서 UI를 픽셀에 가깝게 재현한다.
색상은 전부 oklch로 정의돼 있으니 그대로 쓰거나, 코드베이스가 hex를 요구하면 아래
"Design Tokens"의 근사 hex를 사용한다.

---

## Screens / Views

### 1. 데스크톱 — 캘린더 뷰 (기본)
- **Purpose**: 한 달의 대회 분포를 한눈에 보고, 날짜를 눌러 그날 대회만 추려본다.
- **Layout**:
  - 전체: 세로 플렉스. 상단 타이틀 행 → 필터 행 → 본문(2단 그리드).
  - 본문 그리드: `grid-template-columns: 1.35fr 1fr`, `gap: 24px`. 좌측=캘린더 카드,
    우측=리스트 카드. 둘 다 `height:100%`로 본문 높이를 채운다.
  - 페이지 좌우 패딩 `32px`, 상단 `24px`.
- **타이틀 행**: 좌측에 "전국 배드민턴 대회"(13px/600/green-strong) + "2026년 6월"
  (30px/800, letter-spacing -0.02em) + 이전/다음 화살표 버튼(34×34, radius 9, 1px line border).
  우측에 검색창(목업, 220px, 40px 높이, radius 11) + 캘린더/리스트 세그먼트 토글.
- **필터 행** (`Filters`): 세그먼트 토글 2개 + 지역 칩 1개. 자세한 명세는 아래 "필터" 참조.
- **캘린더 카드**: 흰 배경, radius 16, 1px line border, padding 20, shadow-sm.
  - 안에 월간 캘린더(range bar 방식, 아래 "캘린더" 참조).
  - 캘린더 아래 범례: "접수중"(green 막대 샘플), "마감 임박"(amber 막대 샘플), 12.5px/ink-3.
  - 카드 하단(`margin-top:auto`)에 **"곧 접수가 마감돼요"** 미니 리스트 — 빈 여백을 채우는
    용도. `BMK.closingSoon()` 상위 4개를 D-day 칩 + 대회명(말줄임) + chevron 행으로.
- **리스트 카드**: 흰 배경, radius 16, 1px line border, shadow-sm, 세로 플렉스.
  - 헤더 행: "6월 전체 대회"(미선택 시) 또는 "6월 14일 (일)"(선택 시) + 개수.
    날짜 선택 상태면 우측에 "전체 보기" 버튼(green-tint 배경, radius 8).
  - 본문: 스크롤 영역. 대회 카드(`CardA`) 세로 나열. 비었으면 "선택한 날짜에 대회가 없어요".
- **초기 상태**: 날짜 **미선택**. 이때 우측 리스트는 **그달 전체 대회**를 보여준다.
  날짜를 누르면 그 날짜(2일 대회는 두 날짜 모두 포함)로 필터된다.

### 2. 데스크톱 — 리스트 뷰
- 세그먼트 토글을 "리스트"로 바꾸면 캘린더가 사라지고 전체 폭 리스트 카드가 된다.
- 헤더 행: "총 N개 대회" + "최신순 ⌄"(정렬, 목업).
- 본문: `column-count: 2; column-gap: 32px`로 2열 흐름 배치된 `CardA` 목록.

### 3. 모바일 — 기본
- **Purpose**: 좁은 화면에서 캘린더로 날짜 감만 잡고, 실제 탐색·비교는 아래 리스트에서.
- **Layout**: 세로 스택. 헤더(목업, 생략 가능) → 타이틀+필터 트리거 → 캘린더 → 리스트.
- **타이틀 행**: "2026년 6월"(21px/800) + chevron(월 선택, 목업). 우측에 **필터 트리거**
  버튼(`FilterTrigger`, 활성 필터 개수 배지).
- **캘린더**: 흰 배경 영역, padding 14, 아래 8px bg 구분선. **점(dot) 방식**(막대 아님).
  대회 있는 날만 셀에 green-tint 배경 + 하단에 작은 점(최대 3개; 마감임박은 amber).
  선택 셀은 green 채움 + 흰 숫자 + 개수. 멀티데이 대회는 진행하는 모든 날짜에 점.
- **리스트**:
  - 날짜 **미선택** 시: `BMK` 전체 대회를 **날짜별 그룹**으로. 각 그룹 위에 sticky 헤더
    (큰 일자 숫자 24px/800 + 요일 + "N개 대회" + 우측 hairline). 그룹 안에 `TimelineCard` 나열.
  - 날짜 **선택** 시: 그 날짜 대회만. 헤더에 "6월 14일 N개" + "전체 보기" 버튼.
- **필터**: 바텀시트(`FilterSheet`). 트리거를 누르면 하단에서 올라온다.

---

## Components

### CardA — 대회 카드 (데스크톱 리스트, 캘린더 우측 리스트)
좌측 날짜 블록 + 본문 + 즐겨찾기 별 아이콘 행.
- 컨테이너: `display:flex; gap:14px; padding:16px 4px; border-bottom:1px solid var(--line-2)`. 클릭 가능.
- **날짜 블록** (flex 0 0 52px, 가운데 정렬):
  - 일자 숫자 22px/800/ink. 2일 대회면 `14` 뒤에 `~15`(13px/700/ink-3) 덧붙임.
  - 그 아래 요일 11.5px/600. 일요일이면 `--urgent` 색. 2일이면 "토~일", 아니면 "토요일".
- **본문** (flex 1):
  - 배지 행: `ScopeBadge`(전국/지역) + `GradeTag`(승급/비승급) + 마감임박이면 `Dday` 칩.
  - 대회명: 15px/700/ink, line-height 1.35, letter-spacing -0.01em.
  - 메타 행: 핀 아이콘 + "지역 · 장소" 13px/ink-3.
- **별 버튼**: 우상단, 18px. 활성 시 green 채움.

### TimelineCard — 모바일 타임라인 카드
날짜 헤더가 그룹 위에 따로 있으므로 날짜 블록 없음.
- `padding:14px 16px; border-bottom:1px solid var(--line-2)`.
- 배지 행(Scope + Grade + 마감임박이면 Dday) → 대회명 15px/700 (text-wrap:pretty) →
  메타 행(2일이면 기간 `6.13(토)~14(일)` green-strong/700, 핀+지역·장소, 접수 마감일).

### ScopeBadge — 전국/지역 배지
- 공통: radius 7, 700 weight, line-height 1. sm: 11px/`2px 7px`, md: 12px/`3px 9px`.
- **전국**: 글자 green-deep, 배경 green-tint-2, border 1px green-line.
- **지역**: 글자 ink-2, 배경 surface-2, border 1px line.

### GradeTag — 승급/비승급 (텍스트, 배경 없음)
- "승급" → green-strong/600, "비승급" → ink-3/600. sm 11px / md 12px.

### Dday — 마감 D-day 칩
- 라벨: `dday===0`이면 "오늘 마감", 아니면 `D-${dday}`. tabular-nums.
- **임박(dday ≤ 5)**: 글자 urgent, 배경 urgent-tint, border 1px (urgent 30% alpha).
- **여유**: 글자 ink-2, 배경 surface-2, border 1px line.
- 크기: 기본 12px/`3px 8px`/radius 8. big: 13px/`5px 11px`.

### FilterSeg / SegGroup / SegRow — 세그먼트 토글 (단일선택)
iOS 세그먼트 컨트롤 패턴. 트랙 + 활성 알약.
- 트랙: `background: surface-2; border:1px solid line; border-radius:11px; padding:3px; gap:2px`.
- 각 옵션 버튼: radius 8, 600 weight. 비활성 ink-3, **활성**은 글자 ink + 배경 surface +
  shadow-sm(살짝 떠보임). sm 13px/`6px 14px`, md 13.5px/`7px 14px`.
- `fluid` 모드: 트랙 `width:100%`, 각 버튼 `flex:1` → 폭을 균등 분할(모바일 잘림 방지).
- `SegGroup`(데스크톱): 작은 라벨(12.5px/600/ink-4) + 비-fluid 세그먼트 가로 배치.
- `SegRow`(예전 모바일 인라인용): 30px 라벨 + fluid 세그먼트. **현재 모바일은 바텀시트라 미사용.**

### Chip — 필터 칩 (지역 등 다중/보조)
- `padding:8px 14px; border-radius:10px; font:13.5px/600; letter-spacing -0.01em`.
- 비활성: 글자 ink-2, 배경 surface, border 1px line.
- **활성**: 글자 green-deep, 배경 green-tint, border 1px green-line.
- (radius는 의도적으로 10px — 카드/세그먼트와 같은 모서리 패밀리. 알약형 999는 폐기함.)

### FilterTrigger — 모바일 필터 트리거 버튼
- `padding:9px 14px; radius:11px; font:14px/600`. 필터 아이콘 + "필터" + 활성 개수 배지.
- 활성(개수>0): 글자 green-deep, 배경 green-tint, border green-line. 그 외 ink-2/surface/line.
- 배지: 최소 18px 원, green 배경, 흰 글자 11.5px/800.

### FilterSheet — 모바일 바텀시트
- 오버레이 `rgba(20,28,24,.4)`, 탭하면 닫힘.
- 시트: 하단 고정, `border-top-left/right-radius:22px`, shadow `0 -8px 32px rgba(20,28,24,.18)`,
  `max-height:82%`. 열림/닫힘은 `transform: translateY(0 / 101%)` + 트랜지션
  `.28s cubic-bezier(.32,.72,0,1)`.
- 상단 핸들바(38×4, line 색). 헤더: "필터"(17px/800) + "초기화"(13.5px/600/ink-3).
- 본문 스크롤. 하단 CTA: 전체폭 green 버튼 radius 13, "대회 N개 보기"(N=결과 개수).
- **배경 스크롤 락 필수**: 열릴 때 `document.body.style.overflow='hidden'`, 닫힐 때 복원.
- `paddingBottom: max(14px, env(safe-area-inset-bottom))`로 노치 대응.
- 내부 필드(`SheetField`): 라벨(13px/700/ink-2) + fluid 세그먼트, `border-bottom 1px line-2`.

### MonthCalendar — 월간 캘린더 (핵심)
주(week) 단위로 렌더. **월요일 시작**, 7열 그리드. `compact` prop으로 데스크톱/모바일 분기.

**데스크톱 (compact=false) — range bar 방식:**
- 요일 헤더: 월~일. 토요일 green-strong, 일요일 urgent, 평일 ink-4. 11.5px/600.
- 각 주는 `position:relative` 행. 위에 날짜 숫자 행(원형 버튼, 선택 시 green 채움+흰 글자),
  그 아래 막대 레인 영역(최대 3레인).
- **막대(range bar)**: 대회의 시작~종료일을 그 주 안에서 가로지르는 막대로. 한 주를 넘는
  멀티데이는 주마다 세그먼트로 쪼갬.
  - 시작 세그먼트면 좌측에 2.5px 컬러 보더 + 좌측 모서리 둥글게. 종료 세그먼트면 우측 둥글게.
  - 배경: 일반 green-tint-2 / 마감임박 urgent-tint. **글자색은 항상 `--ink`(가독성).**
  - 시작 세그먼트에만 대회명 텍스트(11px/700, 말줄임) 표시.
  - 레인 배치: 같은 주에서 겹치지 않게 그리디로 레인 할당. 4번째 이상은 "+N" 표기.
- 레인 높이 19px, 막대 높이 16px, 날짜 행 높이 28px.

**모바일 (compact=true) — 점(dot) 방식:**
- 일반 7열 셀 그리드(`gap:2`), 셀 높이 40, radius 11.
- 대회 있는 날: green-tint 배경 + 숫자 아래 점(최대 3개; 마감임박 amber, 그 외 green).
- 선택 날: green 채움 + 흰 숫자 + 개수(10px). 멀티데이는 진행 날짜마다 점(데이터의
  `byDay`가 기간 내 모든 날짜에 대회를 매핑하므로 자동).

---

## Interactions & Behavior
- **세그먼트 토글(구분/승급)**: 단일선택. 값 변경 시 즉시 리스트/캘린더 필터링.
- **지역 칩**: 데스크톱 A에서는 토글(누르면 '부산' 데모값 ↔ 해제). 실제로는 지역 선택
  드롭다운/시트로 확장 필요(현재는 데모).
- **캘린더 날짜 클릭**: 대회 있는 날만 클릭 가능. 클릭 → 그 날짜로 리스트 필터(`day` 상태).
  "전체 보기" → `day=null`로 복귀(그달 전체).
- **캘린더/리스트 세그먼트(데스크톱)**: 본문 영역만 교체.
- **모바일 필터 트리거 → 바텀시트**: 시트 안에서 세그먼트/칩/토글 조작. CTA 또는 오버레이
  탭으로 닫힘. 닫혀도 선택값 유지(실시간 반영, "취소" 없음 — 즉시 적용 모델).
- **트랜지션**: 칩/세그먼트/토글 hover·active `.14~.18s`. 시트 슬라이드 `.28s` 커스텀 이징.
- **반응형 분기 기준**: 데스크톱(2단, range bar 캘린더) vs 모바일(단일 컬럼, dot 캘린더,
  바텀시트). 프로토타입은 데스크톱 1280×880 / 모바일 390×844 아트보드로 분리돼 있다.
  실제 구현은 대략 `~768px` 미만을 모바일 레이아웃으로 보면 된다.

## State Management
컴포넌트 로컬 상태로 충분(서버 상태는 대회 목록 fetch만):
- `view`: `'calendar' | 'list'` — 데스크톱 본문 전환.
- `day`: `number | null` — 선택 날짜(1~31). null이면 그달 전체.
- 필터(`useFilter`): `scope`('전체'|'전국'|'지역'), `grade`('전체'|'승급'|'비승급'),
  `region`(string|null), `fav`(즐겨찾기 맵). `filter(list)`가 세 조건을 AND로 적용.
- `sheet`: boolean — 모바일 바텀시트 열림.
- 필터 활성 개수 = (scope≠전체) + (grade≠전체) + (region) → 트리거 배지에 표시.

### 데이터 모델 (`data.js`의 각 대회 객체)
```
{
  id, name,                       // 식별자, 대회명
  date, endDate,                  // 시작/종료일 'YYYY-MM-DD' (endDate=null이면 단일일)
  region, venue,                  // 지역, 장소
  deadline,                       // 접수 마감일 'YYYY-MM-DD' | null
  scope,                          // '전국' | '지역'
  grade,                          // '승급' | '비승급'
  sponsor,                        // string | null
  views,                          // 조회수(인기순 정렬용)
  // 파생 필드:
  day, month, weekday, dow,       // 시작일 분해 (dow='토' 등 한글 요일)
  endDay, endMonth, endWeekday, endDow,
  multiDay,                       // 2일 이상이면 true
  dday,                           // 마감까지 남은 일수 (today 기준) | null
  status,                         // 'open' | 'soon'(dday≤5) | 'closed'(dday<0)
}
```
헬퍼: `fmtRange(t)` → "6.14(일)" 또는 "6.13(토)~14(일)". `fmtDate(d)` → "6.5".
`byDay(year, month)` → `{ [day]: 대회[] }` (멀티데이는 기간 내 모든 날짜에 포함).
`closingSoon()` → dday 0~8 대회를 임박순 정렬.
**오늘 날짜**는 프로토타입에서 `2026-05-30`으로 고정돼 있다(데모용). 실제로는 `new Date()`.

## Design Tokens
모두 `source/shared.jsx`의 `:root`에 oklch로 정의. 괄호는 근사 hex.

**Green (브랜드, 기존 #31AA60을 채도·명도 낮춰 정제):**
- `--green` oklch(0.62 0.118 158) ≈ `#3DA968`
- `--green-strong` oklch(0.50 0.105 158) ≈ `#2C8551`
- `--green-deep` oklch(0.40 0.085 158) ≈ `#22663E`
- `--green-tint` oklch(0.965 0.022 158) ≈ `#EBF7F0`
- `--green-tint-2` oklch(0.93 0.045 158) ≈ `#D5EEDF`
- `--green-line` oklch(0.88 0.05 158) ≈ `#BFE3CD`

**Ink (중립 텍스트, green 기운 미세하게):**
- `--ink` oklch(0.24 0.008 160) ≈ `#27302B` (본문/제목)
- `--ink-2` oklch(0.44 0.010 160) ≈ `#5A655E`
- `--ink-3` oklch(0.60 0.012 162) ≈ `#838E87`
- `--ink-4` oklch(0.72 0.010 162) ≈ `#A8B0AA` (가장 흐린 메타)

**Lines / Surfaces:**
- `--line` oklch(0.922 0.005 160) ≈ `#E5E8E6`
- `--line-2` oklch(0.955 0.004 160) ≈ `#F0F2F1`
- `--bg` oklch(0.985 0.004 150) ≈ `#FAFBFA` (페이지 배경)
- `--surface` `#FFFFFF` (카드)
- `--surface-2` oklch(0.975 0.006 158) ≈ `#F4F6F5` (세그먼트 트랙, 흐린 배지)

**Urgent (마감 임박 — 이 신호 한 곳에만):**
- `--urgent` oklch(0.64 0.155 47) ≈ `#D9803A`
- `--urgent-tint` oklch(0.955 0.04 60) ≈ `#FAEFE4`

**기타:**
- `--radius: 16px` (카드). 칩/세그먼트 옵션 8~11px. 시트 22px. CTA 13px.
- `--shadow-sm: 0 1px 2px rgba(20,30,24,.05), 0 1px 3px rgba(20,30,24,.04)`
- `--shadow-md: 0 2px 8px rgba(20,30,24,.06), 0 8px 24px rgba(20,30,24,.05)`
- 폰트: **Pretendard Variable** (한글 UI 표준). `font-feature-settings:"tnum"`는 숫자에만
  (`.tnum` 클래스 / tabular-nums) — 날짜·D-day·개수에 적용해 정렬 안정화.

### 타이포 스케일 (실측)
- 페이지 제목 "2026년 6월": 30px / 800 / -0.02em (모바일 21px)
- 카드 대회명: 15px / 700 / 1.35 / -0.01em
- 배지·메타: 11~13.5px
- 섹션 라벨(green): 13px / 600
- 본문 최소: 11.5px (요일/범례). 그 이하로 줄이지 말 것.

## Assets
- **아이콘**: 외부 라이브러리 없이 인라인 SVG(stroke 1.7, 24×24 viewBox). `shared.jsx`의
  `I` 객체에 cal/list/search/pin/clock/chevL/R/D/bell/star/arrow/filter 정의. 코드베이스에
  아이콘셋(lucide 등)이 있으면 동일 의미로 치환 가능.
- **이미지 없음.** 로고는 워드마크(텍스트 "배드민톡" + green 점)뿐 — 헤더와 함께 무시.
- 폰트: Pretendard CDN(`cdn.jsdelivr.net/gh/orioncactus/pretendard`). 코드베이스에 이미
  Pretendard가 있으면 그걸 쓴다.

## Files
`source/` 안:
- **`variantA.jsx`** — 구현 대상. `Desktop`/`Mobile` 컴포넌트, `CardA`, `TimelineCard`,
  `MiniRow`(곧 마감), `Filters`, `useFilter`, `groupByDate`. **여기의 `Header`(목업)는 제외.**
- **`shared.jsx`** — 디자인 토큰(:root) + 공통 컴포넌트(ScopeBadge, GradeTag, Dday,
  FilterSeg/SegGroup/SegRow, Chip, FilterTrigger/FilterSheet/SheetField, MonthCalendar) + 아이콘 `I`.
- **`data.js`** — 샘플 대회 14건 + 파생 필드 계산 + 헬퍼(byDay/fmtRange/closingSoon 등).
  실제 데이터 스키마와 헬퍼 로직의 레퍼런스로 사용.

원본 통합 미리보기는 프로젝트 루트의 `대회페이지 리디자인.html`(디자인 캔버스, 시안 A/B/C 동시).
시안 A 데스크톱/모바일 아트보드만 참고하면 된다.

## 구현 우선순위(권장)
1. 데이터 어댑터: 백엔드 응답 → 위 데이터 모델(파생 필드 포함)로 변환.
2. 공통 컴포넌트(배지/칩/세그먼트/Dday) + 토큰을 코드베이스 디자인시스템에 매핑.
3. `MonthCalendar` — range bar(데스크톱)는 가장 까다로운 부분. 주 단위 레인 배치 로직을
   `shared.jsx`에서 그대로 참고. 모바일 dot는 단순.
4. 리스트(`CardA`/`TimelineCard`) + 필터 연결.
5. 모바일 바텀시트 + 스크롤 락 + safe-area.
