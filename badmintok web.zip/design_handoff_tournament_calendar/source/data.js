/* badmintok 대회 데이터 — 오늘=2026-05-30 기준. 실제 대회명/지역 기반의 현실적 데이터셋.
   일부 대회는 토~일 2일간 진행(end 종료일)된다. */
(function () {
  const TODAY = new Date(2026, 4, 30); // 2026-05-30
  const DOW = ['일', '월', '화', '수', '목', '금', '토'];

  // [name, date(YYYY-MM-DD), 지역, 장소, 접수마감|null, scope, grade, sponsor|null, views, endDate|null]
  const RAW = [
    ['제6회 저소득층 학생선수 한마음 배드민턴 축제', '2026-06-06', '서울', '잠실학생체육관', '2026-05-31', '전국', '비승급', null, 142, null],
    ['제19회 산청군 산림조합장기 배드민턴대회', '2026-06-06', '경남', '산청국민체육센터', '2026-06-01', '지역', '비승급', null, 88, null],
    ['제1회 대전광역시 여성 배드민턴대회', '2026-06-07', '대전', '한밭종합운동장 보조경기장', '2026-06-01', '지역', '승급', null, 211, null],
    ['제2회 목포시 체육회장기 배드민턴대회', '2026-06-09', '전남', '목포실내체육관', '2026-06-04', '지역', '승급', null, 55, null],
    ['제6회 윤봉길배 전국배드민턴대회', '2026-06-13', '충남', '예산스포츠센터', '2026-06-05', '전국', '승급', '요넥스 코리아', 173, '2026-06-14'],
    ['스포츠클럽 디비전리그 시니어 남자부 3차전', '2026-06-13', '경기', '수원 실내체육관', '2026-06-05', '전국', '비승급', null, 162, '2026-06-14'],
    ['제19회 화성특례시 시장기 배드민턴대회', '2026-06-14', '경기', '화성종합경기타운', '2026-06-02', '지역', '승급', null, 304, null],
    ['제13회 부산 남구 청년부 배드민턴대회', '2026-06-14', '부산', '남구 국민체육센터 제2체육관', '2026-06-07', '지역', '승급', '인투스', 195, null],
    ['제8회 박원욱병원장배 부산 여성연맹대회', '2026-06-20', '부산', '강서실내체육관', '2026-06-10', '지역', '승급', '버디 엑시언트', 179, '2026-06-21'],
    ['2026 인천 디비전리그 시니어부 남자 A 3차전', '2026-06-20', '인천', '인천 도원체육관', '2026-06-12', '지역', '승급', null, 138, '2026-06-21'],
    ['경동도시가스배 울산 MBC 초청 전국 OPEN', '2026-06-21', '울산', '동천체육관', '2026-06-12', '전국', '비승급', null, 103, null],
    ['2026 안동시장배 배드민턴 리그전 2차', '2026-06-27', '경북', '용상다목적체육관', '2026-06-18', '지역', '승급', null, 96, '2026-06-28'],
    ['제13회 강서구배드민턴협회 여성부 대회', '2026-06-28', '부산', '강서체육공원 보조경기장', '2026-06-15', '지역', '승급', '스트로커스', 211, null],
    ['제4회 렉스배 SSP 전국 배드민턴대회', '2026-07-05', '서울', '강서구 마곡배드민턴장', '2026-06-25', '전국', '비승급', 'OPTIMO', 94, null],
  ];

  function parse(d) { const [y, m, day] = d.split('-').map(Number); return new Date(y, m - 1, day); }
  function dday(deadline) { return deadline ? Math.round((parse(deadline) - TODAY) / 86400000) : null; }
  function fmtDate(d) { const dt = parse(d); return `${dt.getMonth() + 1}.${dt.getDate()}`; }

  const TOURNAMENTS = RAW.map((r, i) => {
    const [name, date, region, venue, deadline, scope, grade, sponsor, views, endDate] = r;
    const sd = parse(date), ed = parse(endDate || date);
    const dd = dday(deadline);
    const multiDay = !!(endDate && endDate !== date);
    let status = 'open';
    if (dd === null) status = 'open';
    else if (dd < 0) status = 'closed';
    else if (dd <= 5) status = 'soon';
    return {
      id: 'c' + i, name, date, endDate, region, venue, deadline, scope, grade, sponsor, views,
      day: sd.getDate(), month: sd.getMonth() + 1, weekday: sd.getDay(), dow: DOW[sd.getDay()],
      endDay: ed.getDate(), endMonth: ed.getMonth() + 1, endWeekday: ed.getDay(), endDow: DOW[ed.getDay()],
      multiDay, dday: dd, status,
    };
  });

  const REGIONS = ['서울', '경기', '인천', '부산', '대구', '광주', '대전', '울산', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'];

  window.BMK = {
    TODAY,
    tournaments: TOURNAMENTS,
    regions: REGIONS,
    parse, dday, fmtDate,
    // 기간형 날짜 표기: 단일일 "6.14(일)" / 2일 "6.13(토)~14(일)"
    fmtRange(t) {
      const base = `${t.month}.${t.day}(${t.dow})`;
      if (!t.multiDay) return base;
      const end = t.endMonth === t.month ? `${t.endDay}(${t.endDow})` : `${t.endMonth}.${t.endDay}(${t.endDow})`;
      return `${base}~${end}`;
    },
    // 특정 월의 날짜별 대회 매핑 — 멀티데이는 진행하는 모든 날짜에 포함
    byDay(year, month /*1-indexed*/) {
      const map = {};
      TOURNAMENTS.forEach((t) => {
        for (let d = t.day; d <= (t.endMonth === month ? t.endDay : 31); d++) {
          if (t.month <= month && (t.endMonth >= month)) {
            if (t.month === month || t.endMonth === month) (map[d] = map[d] || []).push(t);
          }
        }
      });
      // 단순화: 같은 달 안에서만 처리 (현재 데이터는 6월 내)
      const clean = {};
      TOURNAMENTS.forEach((t) => {
        if (t.month !== month) return;
        const last = t.endMonth === month ? t.endDay : t.day;
        for (let d = t.day; d <= last; d++) (clean[d] = clean[d] || []).push(t);
      });
      return clean;
    },
    closingSoon() {
      return TOURNAMENTS.filter((t) => t.dday !== null && t.dday >= 0 && t.dday <= 8).sort((a, b) => a.dday - b.dday);
    },
  };
})();
