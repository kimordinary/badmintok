/* shared.jsx — 배드민톡 리디자인 공통 디자인 토큰 + 컴포넌트
   모든 시안(A/B/C)이 공유한다. window 로 export. */

// ── 디자인 토큰 (1회 주입) ────────────────────────────────────
if (!document.getElementById('bmk-tokens')) {
  const s = document.createElement('style');
  s.id = 'bmk-tokens';
  s.textContent = `
  :root{
    /* 정제된 브랜드 그린 (#31AA60 → 살짝 깊고 차분하게) */
    --green:        oklch(0.62 0.118 158);
    --green-strong: oklch(0.50 0.105 158);
    --green-deep:   oklch(0.40 0.085 158);
    --green-tint:   oklch(0.965 0.022 158);
    --green-tint-2: oklch(0.93 0.045 158);
    --green-line:   oklch(0.88 0.05 158);
    /* 잉크 (웜-쿨 중립, 그린 기운 살짝) */
    --ink:    oklch(0.24 0.008 160);
    --ink-2:  oklch(0.44 0.010 160);
    --ink-3:  oklch(0.60 0.012 162);
    --ink-4:  oklch(0.72 0.010 162);
    --line:   oklch(0.922 0.005 160);
    --line-2: oklch(0.955 0.004 160);
    --bg:     oklch(0.985 0.004 150);
    --surface:#ffffff;
    --surface-2: oklch(0.975 0.006 158);
    /* 마감 임박 강조 (앰버) */
    --urgent:      oklch(0.64 0.155 47);
    --urgent-tint: oklch(0.955 0.04 60);
    --radius: 16px;
    --shadow-sm: 0 1px 2px rgba(20,30,24,.05), 0 1px 3px rgba(20,30,24,.04);
    --shadow-md: 0 2px 8px rgba(20,30,24,.06), 0 8px 24px rgba(20,30,24,.05);
    --font: "Pretendard Variable","Pretendard",-apple-system,BlinkMacSystemFont,system-ui,sans-serif;
  }
  .bmk{font-family:var(--font);color:var(--ink);-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;
       box-sizing:border-box;font-feature-settings:"tnum" 0;}
  .bmk *,.bmk *::before,.bmk *::after{box-sizing:border-box;}
  .bmk button{font-family:inherit;cursor:pointer;border:none;background:none;color:inherit;white-space:nowrap;}
  .bmk h1{white-space:nowrap;}
  .bmk .tnum{font-variant-numeric:tabular-nums;font-feature-settings:"tnum" 1;}
  .bmk-scroll{overflow-y:auto;scrollbar-width:none;}
  .bmk-scroll::-webkit-scrollbar{display:none;}
  `;
  document.head.appendChild(s);
}

// ── 아이콘 (단순 stroke) ──────────────────────────────────────
const I = {
  cal: (p = {}) => (<svg width={p.s || 18} height={p.s || 18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><rect x="3.5" y="5" width="17" height="16" rx="2.5"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/></svg>),
  list: (p = {}) => (<svg width={p.s || 18} height={p.s || 18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M8 6.5h12M8 12h12M8 17.5h12M4 6.5h.01M4 12h.01M4 17.5h.01"/></svg>),
  search: (p = {}) => (<svg width={p.s || 18} height={p.s || 18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-3.6-3.6"/></svg>),
  pin: (p = {}) => (<svg width={p.s || 16} height={p.s || 16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11z"/><circle cx="12" cy="10" r="2.4"/></svg>),
  clock: (p = {}) => (<svg width={p.s || 16} height={p.s || 16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>),
  filter: (p = {}) => (<svg width={p.s || 18} height={p.s || 18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M4 6h16M7 12h10M10 18h4"/></svg>),
  chevL: (p = {}) => (<svg width={p.s || 18} height={p.s || 18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 5l-7 7 7 7"/></svg>),
  chevR: (p = {}) => (<svg width={p.s || 18} height={p.s || 18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 5l7 7-7 7"/></svg>),
  chevD: (p = {}) => (<svg width={p.s || 16} height={p.s || 16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 9l7 7 7-7"/></svg>),
  bell: (p = {}) => (<svg width={p.s || 18} height={p.s || 18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6zM9.5 19a2.5 2.5 0 0 0 5 0"/></svg>),
  star: (p = {}) => (<svg width={p.s || 18} height={p.s || 18} viewBox="0 0 24 24" fill={p.fill || 'none'} stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 17l-5.2 2.7 1-5.8L3.5 9.7l5.9-.9z"/></svg>),
  arrow: (p = {}) => (<svg width={p.s || 16} height={p.s || 16} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>),
};

// ── 로고 (워드마크 + 점) ─────────────────────────────────────
function Logo({ size = 19, mark = true }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7, fontWeight: 800, fontSize: size, letterSpacing: '-0.03em', color: 'var(--ink)', whiteSpace: 'nowrap', flexShrink: 0 }}>
      {mark && <span style={{ width: size * 0.42, height: size * 0.42, borderRadius: '50%', background: 'var(--green)', display: 'inline-block', boxShadow: '0 0 0 3px var(--green-tint-2)' }} />}
      배드민<span style={{ color: 'var(--green-strong)' }}>톡</span>
    </span>
  );
}

// ── 배지: 전국/지역 ──────────────────────────────────────────
function ScopeBadge({ scope, size = 'md' }) {
  const nat = scope === '전국';
  const pad = size === 'sm' ? '2px 7px' : '3px 9px';
  const fs = size === 'sm' ? 11 : 12;
  return (
    <span style={{
      padding: pad, fontSize: fs, fontWeight: 700, borderRadius: 7, lineHeight: 1, whiteSpace: 'nowrap',
      color: nat ? 'var(--green-deep)' : 'var(--ink-2)',
      background: nat ? 'var(--green-tint-2)' : 'var(--surface-2)',
      border: nat ? '1px solid var(--green-line)' : '1px solid var(--line)',
    }}>{scope}</span>
  );
}

// ── 배지: 승급/비승급 (텍스트) ───────────────────────────────
function GradeTag({ grade, size = 'md' }) {
  const up = grade === '승급';
  const fs = size === 'sm' ? 11 : 12;
  return (
    <span style={{ fontSize: fs, fontWeight: 600, color: up ? 'var(--green-strong)' : 'var(--ink-3)', whiteSpace: 'nowrap' }}>
      {up ? '승급' : '비승급'}
    </span>
  );
}

// ── D-day 칩 ─────────────────────────────────────────────────
function Dday({ dday, big = false }) {
  if (dday === null) return null;
  const urgent = dday <= 5;
  const label = dday === 0 ? '오늘 마감' : `D-${dday}`;
  return (
    <span className="tnum" style={{
      display: 'inline-flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap', flexShrink: 0,
      padding: big ? '5px 11px' : '3px 8px', fontSize: big ? 13 : 12, fontWeight: 700, borderRadius: 8, lineHeight: 1,
      color: urgent ? 'var(--urgent)' : 'var(--ink-2)',
      background: urgent ? 'var(--urgent-tint)' : 'var(--surface-2)',
      border: urgent ? '1px solid color-mix(in oklab, var(--urgent) 30%, transparent)' : '1px solid var(--line)',
    }}>{label}</span>
  );
}

// ── 세그먼트 토글 (캘린더|리스트 등) ─────────────────────────
function Segmented({ options, value, onChange, size = 'md' }) {
  const h = size === 'sm' ? 34 : 40;
  return (
    <div style={{ display: 'inline-flex', background: 'var(--surface-2)', borderRadius: 11, padding: 3, gap: 2, border: '1px solid var(--line)' }}>
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button key={o.value} onClick={() => onChange(o.value)} style={{
            display: 'inline-flex', alignItems: 'center', gap: 6, height: h - 6, padding: '0 14px', borderRadius: 8,
            fontSize: size === 'sm' ? 13 : 14, fontWeight: 600, letterSpacing: '-0.01em', transition: 'all .16s',
            color: active ? 'var(--ink)' : 'var(--ink-3)',
            background: active ? 'var(--surface)' : 'transparent',
            boxShadow: active ? 'var(--shadow-sm)' : 'none',
          }}>{o.icon}{o.label}</button>
        );
      })}
    </div>
  );
}

// ── 필터 칩 ──────────────────────────────────────────────────
function Chip({ children, active, onClick, count }) {
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, padding: '8px 14px', borderRadius: 10,
      fontSize: 13.5, fontWeight: 600, letterSpacing: '-0.01em', whiteSpace: 'nowrap', transition: 'all .16s',
      color: active ? 'var(--green-deep)' : 'var(--ink-2)',
      background: active ? 'var(--green-tint)' : 'var(--surface)',
      border: active ? '1px solid var(--green-line)' : '1px solid var(--line)',
    }}>
      {children}
      {count != null && <span className="tnum" style={{ fontSize: 12, color: active ? 'var(--green-strong)' : 'var(--ink-4)' }}>{count}</span>}
    </button>
  );
}

// ── 필터 세그먼트 토글 (단일선택 그룹) ───────────────────────
function FilterSeg({ options, value, onChange, size = 'md', fluid = false }) {
  const padV = size === 'sm' ? 6 : 7;
  const fs = size === 'sm' ? 13 : 13.5;
  return (
    <div style={{ display: fluid ? 'flex' : 'inline-flex', width: fluid ? '100%' : 'auto', background: 'var(--surface-2)', borderRadius: 11, padding: 3, gap: 2, border: '1px solid var(--line)', flexShrink: fluid ? 1 : 0 }}>
      {options.map((o) => {
        const active = o === value;
        return (
          <button key={o} onClick={() => onChange(o)} style={{
            flex: fluid ? 1 : 'none',
            padding: `${padV}px 14px`, borderRadius: 8, fontSize: fs, fontWeight: 600, letterSpacing: '-0.01em', transition: 'all .16s', whiteSpace: 'nowrap',
            color: active ? 'var(--ink)' : 'var(--ink-3)',
            background: active ? 'var(--surface)' : 'transparent',
            boxShadow: active ? 'var(--shadow-sm)' : 'none',
          }}>{o}</button>
        );
      })}
    </div>
  );
}

// 라벨 + fluid 세그먼트 한 줄 (모바일 필터용)
function SegRow({ label, options, value, onChange }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-4)', width: 30, flexShrink: 0 }}>{label}</span>
      <FilterSeg size="sm" fluid options={options} value={value} onChange={onChange} />
    </div>
  );
}

// 라벨 + 세그먼트 묶음 (데스크톱 필터 바용)
function SegGroup({ label, options, value, onChange, size }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--ink-4)', flexShrink: 0 }}>{label}</span>
      <FilterSeg options={options} value={value} onChange={onChange} size={size} />
    </div>
  );
}

// ── 월 캘린더 (range bar 방식 — 멀티데이 대회를 막대로 연결) ──
// onPick(day) — 날짜 선택. selected — 선택된 day. compact — 모바일용(라벨 없는 얇은 막대).
function MonthCalendar({ year = 2026, month = 6, selected, onPick, compact = false }) {
  const byDay = window.BMK.byDay(year, month);
  const evs = window.BMK.tournaments.filter((t) => t.month === month);
  const first = new Date(year, month - 1, 1);
  const startDow = (first.getDay() + 6) % 7; // 월요일 시작
  const daysIn = new Date(year, month, 0).getDate();
  const weekCount = Math.ceil((startDow + daysIn) / 7);
  const dows = ['월', '화', '수', '목', '금', '토', '일'];
  const colOf = (day) => (startDow + day - 1) % 7;

  // 모바일(compact): 셀이 작아 대회명이 안 보이므로 점(dot) 방식으로 복귀.
  // 실제 탐색은 아래 리스트에서. 멀티데이는 진행하는 모든 날짜에 점 표시(byDay가 처리).
  if (compact) {
    const cells = [];
    for (let i = 0; i < startDow; i++) cells.push(null);
    for (let d = 1; d <= daysIn; d++) cells.push(d);
    while (cells.length % 7 !== 0) cells.push(null);
    const cellH = 40;
    return (
      <div style={{ width: '100%' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', marginBottom: 2 }}>
          {dows.map((d, i) => (
            <div key={d} style={{ textAlign: 'center', fontSize: 11.5, fontWeight: 600, padding: '4px 0',
              color: i === 5 ? 'var(--green-strong)' : i === 6 ? 'var(--urgent)' : 'var(--ink-4)' }}>{d}</div>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 2 }}>
          {cells.map((d, i) => {
            if (!d) return <div key={i} style={{ height: cellH }} />;
            const dayEvs = byDay[d] || [];
            const has = dayEvs.length > 0;
            const sel = selected === d;
            return (
              <button key={i} onClick={() => has && onPick && onPick(d)} style={{
                height: cellH, borderRadius: 11, position: 'relative', transition: 'all .14s',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 3,
                cursor: has ? 'pointer' : 'default',
                background: sel ? 'var(--green)' : has ? 'var(--green-tint)' : 'transparent',
                color: sel ? '#fff' : has ? 'var(--green-deep)' : 'var(--ink-4)', fontWeight: has ? 700 : 500,
              }}>
                <span className="tnum" style={{ fontSize: 13 }}>{d}</span>
                {has && !sel && (
                  <span style={{ display: 'flex', gap: 2 }}>
                    {dayEvs.slice(0, 3).map((e, j) => (
                      <span key={j} style={{ width: 4, height: 4, borderRadius: '50%',
                        background: e.status === 'soon' ? 'var(--urgent)' : 'var(--green)' }} />
                    ))}
                  </span>
                )}
                {has && sel && <span className="tnum" style={{ fontSize: 10, fontWeight: 700, opacity: .95 }}>{dayEvs.length}</span>}
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  const dayRowH = compact ? 26 : 28;
  const laneH = compact ? 6 : 19;     // 한 레인 높이(막대+간격)
  const barH = compact ? 4 : 16;
  const maxLanes = 3;
  const weekH = dayRowH + maxLanes * laneH + (compact ? 4 : 6);

  // 주별 막대 세그먼트 + 레인 배치
  const weeks = [];
  for (let w = 0; w < weekCount; w++) {
    const weekFirstDay = Math.max(1, w * 7 - startDow + 1);
    const weekLastDay = Math.min(daysIn, w * 7 + 6 - startDow + 1);
    const days = [];
    for (let c = 0; c < 7; c++) { const day = w * 7 + c - startDow + 1; days.push(day >= 1 && day <= daysIn ? day : null); }
    const segs = evs.map((t) => {
      const s = t.day, e = t.endMonth === month ? t.endDay : daysIn;
      const segS = Math.max(s, weekFirstDay), segE = Math.min(e, weekLastDay);
      if (segS > segE || weekFirstDay > weekLastDay) return null;
      return { t, segS, colStart: colOf(segS), colEnd: colOf(segE), isStart: segS === s, isEnd: segE === e, soon: t.status === 'soon' };
    }).filter(Boolean).sort((a, b) => a.colStart - b.colStart || (b.colEnd - b.colStart) - (a.colEnd - a.colStart));
    const lanes = [];
    segs.forEach((seg) => {
      let lane = 0;
      while (lanes[lane] && lanes[lane].some((o) => !(seg.colStart > o.colEnd || seg.colEnd < o.colStart))) lane++;
      (lanes[lane] = lanes[lane] || []).push(seg); seg.lane = lane;
    });
    weeks.push({ days, segs, laneCount: lanes.length });
  }

  return (
    <div style={{ width: '100%' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', marginBottom: 2 }}>
        {dows.map((d, i) => (
          <div key={d} style={{ textAlign: 'center', fontSize: 11.5, fontWeight: 600, padding: '4px 0',
            color: i === 5 ? 'var(--green-strong)' : i === 6 ? 'var(--urgent)' : 'var(--ink-4)' }}>{d}</div>
        ))}
      </div>
      {weeks.map((wk, wi) => (
        <div key={wi} style={{ position: 'relative', height: weekH, borderTop: '1px solid var(--line-2)' }}>
          {/* 날짜 숫자 */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', position: 'absolute', inset: 0 }}>
            {wk.days.map((d, ci) => {
              if (!d) return <div key={ci} />;
              const has = !!(byDay[d] || []).length;
              const sel = selected === d;
              return (
                <div key={ci} style={{ display: 'flex', justifyContent: 'center', paddingTop: 4 }}>
                  <button onClick={() => has && onPick && onPick(d)} style={{
                    width: dayRowH - 6, height: dayRowH - 6, borderRadius: '50%', display: 'grid', placeItems: 'center',
                    cursor: has ? 'pointer' : 'default', transition: 'all .14s',
                    background: sel ? 'var(--green)' : 'transparent',
                    color: sel ? '#fff' : has ? 'var(--ink)' : 'var(--ink-4)', fontWeight: has ? 700 : 500,
                  }}>
                    <span className="tnum" style={{ fontSize: compact ? 12.5 : 13.5 }}>{d}</span>
                  </button>
                </div>
              );
            })}
          </div>
          {/* range 막대 */}
          {wk.segs.filter((s) => s.lane < maxLanes).map((seg, si) => {
            const left = `calc(${(seg.colStart / 7) * 100}% + 3px)`;
            const width = `calc(${((seg.colEnd - seg.colStart + 1) / 7) * 100}% - 6px)`;
            const top = dayRowH + seg.lane * laneH;
            return (
              <button key={si} onClick={() => onPick && onPick(seg.t.day)} title={seg.t.name} style={{
                position: 'absolute', left, width, top, height: barH, display: 'flex', alignItems: 'center',
                padding: compact ? 0 : '0 7px', overflow: 'hidden', cursor: 'pointer',
                background: seg.soon ? 'var(--urgent-tint)' : 'var(--green-tint-2)',
                color: 'var(--ink)',
                borderLeft: seg.isStart ? `2.5px solid ${seg.soon ? 'var(--urgent)' : 'var(--green)'}` : 'none',
                borderTopLeftRadius: seg.isStart ? 5 : 0, borderBottomLeftRadius: seg.isStart ? 5 : 0,
                borderTopRightRadius: seg.isEnd ? 5 : 0, borderBottomRightRadius: seg.isEnd ? 5 : 0,
                fontSize: 11, fontWeight: 700, whiteSpace: 'nowrap', textOverflow: 'ellipsis',
              }}>
                {!compact && seg.isStart && <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{seg.t.name}</span>}
              </button>
            );
          })}
          {/* +N more */}
          {wk.days.map((d, ci) => {
            if (!d) return null;
            const extra = wk.segs.filter((s) => s.lane >= maxLanes && s.colStart === colOf(d) && s.isStart).length;
            if (!extra) return null;
            return (
              <div key={'m' + ci} style={{ position: 'absolute', left: `calc(${(colOf(d) / 7) * 100}% + 3px)`,
                top: dayRowH + maxLanes * laneH - (compact ? 2 : 0), fontSize: 9.5, fontWeight: 700, color: 'var(--ink-4)' }} className="tnum">+{extra}</div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

// ── 모바일 필터 바텀시트 ─────────────────────────────────────
// 트리거 버튼(활성 개수 배지) + 하단에서 올라오는 시트. 배경 스크롤 락 포함.
function FilterTrigger({ activeCount, onClick }) {
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 14px', borderRadius: 11,
      fontSize: 14, fontWeight: 600, color: activeCount ? 'var(--green-deep)' : 'var(--ink-2)',
      background: activeCount ? 'var(--green-tint)' : 'var(--surface)',
      border: activeCount ? '1px solid var(--green-line)' : '1px solid var(--line)', flexShrink: 0,
    }}>
      {window.BMKI.filter({ s: 17 })}
      필터
      {activeCount > 0 && <span className="tnum" style={{ minWidth: 18, height: 18, padding: '0 5px', borderRadius: 9, background: 'var(--green)', color: '#fff', fontSize: 11.5, fontWeight: 800, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{activeCount}</span>}
    </button>
  );
}

function FilterSheet({ open, onClose, children, onReset, onApply, resultCount }) {
  React.useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, [open]);
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 50, pointerEvents: open ? 'auto' : 'none' }}>
      {/* 오버레이 */}
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(20,28,24,.4)', opacity: open ? 1 : 0, transition: 'opacity .25s' }} />
      {/* 시트 */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, background: 'var(--surface)',
        borderTopLeftRadius: 22, borderTopRightRadius: 22, boxShadow: '0 -8px 32px rgba(20,28,24,.18)',
        transform: open ? 'translateY(0)' : 'translateY(101%)', transition: 'transform .28s cubic-bezier(.32,.72,0,1)',
        display: 'flex', flexDirection: 'column', maxHeight: '82%',
      }}>
        <div style={{ padding: '10px 0 4px', display: 'flex', justifyContent: 'center' }}>
          <span style={{ width: 38, height: 4, borderRadius: 2, background: 'var(--line)' }} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 20px 14px', borderBottom: '1px solid var(--line-2)' }}>
          <span style={{ fontSize: 17, fontWeight: 800, letterSpacing: '-0.01em' }}>필터</span>
          <button onClick={onReset} style={{ fontSize: 13.5, fontWeight: 600, color: 'var(--ink-3)' }}>초기화</button>
        </div>
        <div className="bmk-scroll" style={{ padding: '4px 20px 8px', overflowY: 'auto' }}>{children}</div>
        <div style={{ padding: '14px 20px', paddingBottom: 'max(14px, env(safe-area-inset-bottom))', borderTop: '1px solid var(--line-2)' }}>
          <button onClick={onApply || onClose} style={{ width: '100%', padding: '14px', borderRadius: 13, background: 'var(--green)', color: '#fff', fontSize: 15.5, fontWeight: 700 }}>
            {resultCount != null ? `대회 ${resultCount}개 보기` : '적용하기'}
          </button>
        </div>
      </div>
    </div>
  );
}

// 시트 내부 한 줄: 라벨 + 풀폭 세그먼트
function SheetField({ label, options, value, onChange }) {
  return (
    <div style={{ padding: '16px 0', borderBottom: '1px solid var(--line-2)' }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink-2)', marginBottom: 11 }}>{label}</div>
      <window.FilterSeg fluid options={options} value={value} onChange={onChange} />
    </div>
  );
}

Object.assign(window, { BMKI: I, Logo, ScopeBadge, GradeTag, Dday, Segmented, Chip, FilterSeg, SegGroup, SegRow, FilterTrigger, FilterSheet, SheetField, MonthCalendar });
