/* variantA.jsx — 시안 A "정석 리파인"
   현재 구조를 그대로 세련되게: 캘린더+선택일 상세 분할, 상단 토글/필터.
   exports: AdeskTop(?) → window.VariantA = { Desktop, Mobile } */

(function () {
  const { BMKI: I, Logo, ScopeBadge, GradeTag, Dday, Segmented, Chip, FilterSeg, SegGroup, SegRow, FilterTrigger, FilterSheet, SheetField, MonthCalendar } = window;
  const BMK = window.BMK;

  // 대회 카드 (시안 A 스타일: 좌측 날짜 블록 + 본문)
  function CardA({ t, onFav, fav }) {
    return (
      <div style={{ display: 'flex', gap: 14, padding: '16px 4px', borderBottom: '1px solid var(--line-2)', cursor: 'pointer' }}>
        <div style={{ flex: '0 0 52px', textAlign: 'center', paddingTop: 2 }}>
          <div className="tnum" style={{ fontSize: 22, fontWeight: 800, color: 'var(--ink)', lineHeight: 1 }}>{t.day}{t.multiDay && <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink-3)' }}>~{t.endDay}</span>}</div>
          <div style={{ fontSize: 11.5, fontWeight: 600, color: t.weekday === 0 ? 'var(--urgent)' : 'var(--ink-3)', marginTop: 3 }}>{t.multiDay ? `${t.dow}~${t.endDow}` : `${t.dow}요일`}</div>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
            <ScopeBadge scope={t.scope} size="sm" />
            <GradeTag grade={t.grade} size="sm" />
            {t.status === 'soon' && <Dday dday={t.dday} />}
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--ink)', lineHeight: 1.35, marginBottom: 6, letterSpacing: '-0.01em' }}>{t.name}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: 'var(--ink-3)' }}>
            <span style={{ color: 'var(--ink-4)' }}>{I.pin({ s: 14 })}</span>
            <span>{t.region} · {t.venue}</span>
          </div>
        </div>
        <button onClick={(e) => { e.stopPropagation(); onFav(t.id); }} style={{ flex: '0 0 auto', color: fav ? 'var(--green)' : 'var(--ink-4)', alignSelf: 'flex-start', padding: 2 }}>
          {I.star({ s: 18, fill: fav ? 'currentColor' : 'none' })}
        </button>
      </div>
    );
  }

  /* 목업 헤더(로고·메뉴·로그인)는 핸드오프에서 제외했다.
     기존 사이트 헤더 아래에 이 기능 영역(필터+캘린더+리스트)만 끼워 넣으면 된다. */

  // 필터 바 (데스크톱 — 세그먼트 토글)
  function Filters({ scope, setScope, grade, setGrade, region, setRegion }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
        <SegGroup label="구분" options={['전체', '전국', '지역']} value={scope} onChange={setScope} />
        <SegGroup label="승급" options={['전체', '승급', '비승급']} value={grade} onChange={setGrade} />
        <Chip active={!!region} onClick={() => setRegion(region ? null : '부산')}>{region || '지역'} {I.chevD({ s: 14 })}</Chip>
      </div>
    );
  }

  function useFilter() {
    const [scope, setScope] = React.useState('전체');
    const [grade, setGrade] = React.useState('전체');
    const [region, setRegion] = React.useState(null);
    const [fav, setFav] = React.useState({});
    const filter = (list) => list.filter((t) =>
      (scope === '전체' || t.scope === scope) &&
      (grade === '전체' || t.grade === grade) &&
      (!region || t.region === region));
    const toggleFav = (id) => setFav((f) => ({ ...f, [id]: !f[id] }));
    return { scope, setScope, grade, setGrade, region, setRegion, fav, toggleFav, filter };
  }

  // 곧 마감 미니 행
  function MiniRow({ t }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 0', borderTop: '1px solid var(--line-2)', cursor: 'pointer' }}>
        <Dday dday={t.dday} />
        <div style={{ flex: 1, minWidth: 0, fontSize: 13, fontWeight: 600, color: 'var(--ink-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.name}</div>
        <span style={{ color: 'var(--ink-4)', flexShrink: 0 }}>{I.chevR({ s: 15 })}</span>
      </div>
    );
  }

  // 날짜별 그룹 (모바일 타임라인용)
  function groupByDate(list) {
    const map = {};
    list.forEach((t) => { (map[t.date] = map[t.date] || []).push(t); });
    return Object.keys(map).sort().map((date) => ({ date, items: map[date], sample: map[date][0] }));
  }

  // 타임라인 카드 (모바일 — 날짜 헤더가 위에 있으므로 날짜블록 생략)
  function TimelineCard({ t, last }) {
    return (
      <div style={{ padding: '14px 16px', borderBottom: last ? 'none' : '1px solid var(--line-2)', cursor: 'pointer' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 7 }}>
          <ScopeBadge scope={t.scope} size="sm" />
          <GradeTag grade={t.grade} size="sm" />
          {t.status === 'soon' && <Dday dday={t.dday} />}
        </div>
        <div style={{ fontSize: 15, fontWeight: 700, lineHeight: 1.35, letterSpacing: '-0.01em', marginBottom: 7, textWrap: 'pretty' }}>{t.name}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, fontSize: 12.5, color: 'var(--ink-3)', flexWrap: 'wrap' }}>
          {t.multiDay && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: 'var(--green-strong)', fontWeight: 700 }}>{I.cal({ s: 13 })}{BMK.fmtRange(t)}</span>}
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>{I.pin({ s: 13 })}{t.region} · {t.venue}</span>
          {t.deadline && <span style={{ color: 'var(--ink-4)' }}>접수 ~{BMK.fmtDate(t.deadline)}</span>}
        </div>
      </div>
    );
  }

  // ── 데스크톱 ────────────────────────────────────────────────
  function Desktop() {
    const [view, setView] = React.useState('calendar');
    const [day, setDay] = React.useState(null); // 최초엔 미선택 → 전체 대회
    const f = useFilter();
    const all = f.filter(BMK.tournaments);
    const byDay = BMK.byDay(2026, 6);
    const dayEvents = f.filter(byDay[day] || []);
    const list = day ? dayEvents : all;
    const soon = BMK.closingSoon().slice(0, 4);

    const seg = (
      <Segmented value={view} onChange={setView} options={[
        { value: 'calendar', label: '캘린더', icon: I.cal({ s: 16 }) },
        { value: 'list', label: '리스트', icon: I.list({ s: 16 }) },
      ]} />
    );

    return (
      <div className="bmk" style={{ width: '100%', height: '100%', background: 'var(--bg)', display: 'flex', flexDirection: 'column' }}>
        <div style={{ flex: 1, minHeight: 0, padding: '24px 32px 0', display: 'flex', flexDirection: 'column' }}>
          {/* 타이틀 행 */}
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 18 }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--green-strong)', marginBottom: 6 }}>전국 배드민턴 대회</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <h1 style={{ margin: 0, fontSize: 30, fontWeight: 800, letterSpacing: '-0.02em' }}>2026년 6월</h1>
                <div style={{ display: 'flex', gap: 4 }}>
                  <button style={{ width: 34, height: 34, borderRadius: 9, border: '1px solid var(--line)', background: 'var(--surface)', display: 'grid', placeItems: 'center', color: 'var(--ink-2)' }}>{I.chevL({ s: 17 })}</button>
                  <button style={{ width: 34, height: 34, borderRadius: 9, border: '1px solid var(--line)', background: 'var(--surface)', display: 'grid', placeItems: 'center', color: 'var(--ink-2)' }}>{I.chevR({ s: 17 })}</button>
                </div>
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0 14px', height: 40, borderRadius: 11, border: '1px solid var(--line)', background: 'var(--surface)', color: 'var(--ink-4)', width: 220 }}>
                {I.search({ s: 16 })}<span style={{ fontSize: 14, color: 'var(--ink-4)' }}>대회명 검색</span>
              </div>
              {seg}
            </div>
          </div>
          <div style={{ marginBottom: 18 }}><Filters {...f} /></div>

          {/* 본문 */}
          {view === 'calendar' ? (
            <div style={{ flex: 1, minHeight: 0, display: 'grid', gridTemplateColumns: '1.35fr 1fr', gap: 24, paddingBottom: 24 }}>
              <div style={{ background: 'var(--surface)', borderRadius: 'var(--radius)', border: '1px solid var(--line)', padding: 20, boxShadow: 'var(--shadow-sm)', display: 'flex', flexDirection: 'column' }}>
                <MonthCalendar year={2026} month={6} selected={day} onPick={setDay} />
                <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--line-2)', fontSize: 12.5, color: 'var(--ink-3)' }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 14, height: 8, borderRadius: 3, background: 'var(--green-tint-2)', borderLeft: '2.5px solid var(--green)' }} />접수중</span>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 14, height: 8, borderRadius: 3, background: 'var(--urgent-tint)', borderLeft: '2.5px solid var(--urgent)' }} />마감 임박</span>
                </div>
                {/* 곧 마감 — 하단 정렬로 여백 채움 */}
                <div style={{ marginTop: 'auto', paddingTop: 18 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 4 }}>
                    <span style={{ width: 6, height: 6, borderRadius: 3, background: 'var(--urgent)' }} />
                    <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink)' }}>곧 접수가 마감돼요</span>
                  </div>
                  {soon.map((t) => <MiniRow key={t.id} t={t} />)}
                </div>
              </div>
              <div style={{ background: 'var(--surface)', borderRadius: 'var(--radius)', border: '1px solid var(--line)', display: 'flex', flexDirection: 'column', minHeight: 0, boxShadow: 'var(--shadow-sm)' }}>
                <div style={{ padding: '15px 18px 13px', borderBottom: '1px solid var(--line-2)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 700 }}>{day ? `6월 ${day}일` : '6월 전체 대회'}{day ? <span style={{ color: 'var(--ink-3)', fontWeight: 500 }}> ({(byDay[day] || [])[0]?.dow || ''})</span> : null}</div>
                    <div style={{ fontSize: 12.5, color: 'var(--ink-3)', marginTop: 2 }}>{list.length}개 대회</div>
                  </div>
                  {day && <button onClick={() => setDay(null)} style={{ fontSize: 13, fontWeight: 600, color: 'var(--green-strong)', padding: '6px 10px', borderRadius: 8, background: 'var(--green-tint)' }}>전체 보기</button>}
                </div>
                <div className="bmk-scroll" style={{ flex: 1, minHeight: 0, padding: '4px 18px 12px' }}>
                  {list.length ? list.map((t) => <CardA key={t.id} t={t} onFav={f.toggleFav} fav={f.fav[t.id]} />)
                    : <div style={{ padding: '48px 0', textAlign: 'center', color: 'var(--ink-4)', fontSize: 13.5 }}>선택한 날짜에 대회가 없어요</div>}
                </div>
              </div>
            </div>
          ) : (
            <div style={{ flex: 1, minHeight: 0, background: 'var(--surface)', borderRadius: 'var(--radius)', border: '1px solid var(--line)', boxShadow: 'var(--shadow-sm)', display: 'flex', flexDirection: 'column' }}>
              <div style={{ padding: '14px 22px', borderBottom: '1px solid var(--line-2)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ fontSize: 14, color: 'var(--ink-3)' }}>총 <b className="tnum" style={{ color: 'var(--ink)' }}>{all.length}</b>개 대회</div>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: 'var(--ink-2)', display: 'flex', alignItems: 'center', gap: 4 }}>최신순 {I.chevD({ s: 14 })}</div>
              </div>
              <div className="bmk-scroll" style={{ flex: 1, minHeight: 0, padding: '0 22px', columnCount: 2, columnGap: 32 }}>
                {all.map((t) => <CardA key={t.id} t={t} onFav={f.toggleFav} fav={f.fav[t.id]} />)}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ── 모바일 (상단 캘린더 유지 + 시안 C형 날짜별 타임라인) ─────
  function Mobile() {
    const [day, setDay] = React.useState(null);
    const [sheet, setSheet] = React.useState(false);
    const f = useFilter();
    const byDay = BMK.byDay(2026, 6);
    const dayEvents = f.filter(byDay[day] || []);
    const all = f.filter(BMK.tournaments);
    const groups = groupByDate(all);
    const activeCount = (f.scope !== '전체' ? 1 : 0) + (f.grade !== '전체' ? 1 : 0) + (f.region ? 1 : 0);

    return (
      <div className="bmk" style={{ width: '100%', height: '100%', background: 'var(--bg)', display: 'flex', flexDirection: 'column', position: 'relative' }}>
        {/* 타이틀 + 필터 트리거 (캘린더는 항상 상단 유지) */}
        <div style={{ padding: '14px 18px 12px', background: 'var(--surface)', borderBottom: '1px solid var(--line)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <h1 style={{ margin: 0, fontSize: 21, fontWeight: 800, letterSpacing: '-0.02em' }}>2026년 6월</h1>
              <button style={{ color: 'var(--ink-3)' }}>{I.chevD({ s: 18 })}</button>
            </div>
            <FilterTrigger activeCount={activeCount} onClick={() => setSheet(true)} />
          </div>
        </div>

        <div className="bmk-scroll" style={{ flex: 1, minHeight: 0 }}>
          {/* 상단 캘린더 */}
          <div style={{ padding: '12px 14px 14px', background: 'var(--surface)', borderBottom: '8px solid var(--bg)' }}>
            <MonthCalendar year={2026} month={6} selected={day} onPick={setDay} compact />
          </div>

          {/* 선택일 → 해당 날짜, 미선택 → 전체 날짜별 타임라인 */}
          {day ? (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 18px 8px' }}>
                <div style={{ fontSize: 15, fontWeight: 800 }}>6월 {day}일 <span style={{ color: 'var(--ink-3)', fontWeight: 500, fontSize: 13 }}>{dayEvents.length}개</span></div>
                <button onClick={() => setDay(null)} style={{ fontSize: 13, fontWeight: 600, color: 'var(--green-strong)', padding: '5px 10px', borderRadius: 8, background: 'var(--green-tint)' }}>전체 보기</button>
              </div>
              <div style={{ padding: '0 8px 24px' }}>
                {dayEvents.length ? dayEvents.map((t, i) => <TimelineCard key={t.id} t={t} last={i === dayEvents.length - 1} />)
                  : <div style={{ padding: '36px 0', textAlign: 'center', color: 'var(--ink-4)', fontSize: 13.5 }}>이 날은 대회가 없어요</div>}
              </div>
            </div>
          ) : (
            <div>
              {groups.map((g) => (
                <div key={g.date}>
                  <div style={{ position: 'sticky', top: 0, zIndex: 2, display: 'flex', alignItems: 'center', gap: 12, padding: '13px 18px 9px', background: 'var(--bg)', borderBottom: '1px solid var(--line-2)' }}>
                    <span className="tnum" style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1 }}>{g.sample.day}</span>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: g.sample.weekday === 0 ? 'var(--urgent)' : 'var(--ink-2)' }}>{g.sample.dow}요일</div>
                      <div style={{ fontSize: 11.5, color: 'var(--ink-4)', fontWeight: 600 }} className="tnum">{g.items.length}개 대회</div>
                    </div>
                    <span style={{ flex: 1, height: 1, background: 'var(--line)' }} />
                  </div>
                  <div style={{ padding: '2px 8px 6px' }}>
                    {g.items.map((t, i) => <TimelineCard key={t.id} t={t} last={i === g.items.length - 1} />)}
                  </div>
                </div>
              ))}
              <div style={{ height: 20 }} />
            </div>
          )}
        </div>

        <FilterSheet open={sheet} onClose={() => setSheet(false)} onReset={() => { f.setScope('전체'); f.setGrade('전체'); f.setRegion(null); }} resultCount={all.length}>
          <SheetField label="구분" options={['전체', '전국', '지역']} value={f.scope} onChange={f.setScope} />
          <SheetField label="승급 여부" options={['전체', '승급', '비승급']} value={f.grade} onChange={f.setGrade} />
        </FilterSheet>
      </div>
    );
  }

  window.VariantA = { Desktop, Mobile };
})();
